Reliability is evaluated using 10 different measurements
in normal environmental condition. Fisrst column of each text 
file denotes Challenge and the 2nd column response bit. The 3rd column
denotes the majority voting. If voting result is >=4 response bit is 1 otherwise 0.
Uniqueness and Reliability are measured using the same data.
