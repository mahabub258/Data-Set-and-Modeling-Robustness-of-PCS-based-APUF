First column of each text file denotes Challenge and the 2nd column response bit. The 3rd column
denotes the majority voting. If voting result is >=4 response bit is 1 otherwise 0.
12,800 CRPs are used for NIST test. Also, out of the 12,800
10,000 are used to evaluate uniquenss and uniformity.