Reliability is evaluated using 10 different measurements
in normal environmental condition. Fisrst column of each text 
file denotes Challenge and the 2nd column response bit. 